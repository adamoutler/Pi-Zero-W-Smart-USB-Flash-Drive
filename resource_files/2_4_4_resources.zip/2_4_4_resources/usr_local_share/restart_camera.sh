#!/bin/bash

sudo killall mjpg_streamer
sudo /usr/local/share/start_camera_stream.sh

exit 0

