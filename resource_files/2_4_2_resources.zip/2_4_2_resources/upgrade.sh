chmod a+w /home/pi/usb_share/scripts/camera_templates/*
cp -f /tmp/2_4_2_resources/camera_templates/* /home/pi/usb_share/scripts/camera_templates
chmod a-w /home/pi/usb_share/scripts/camera_templates/*
sudo sed -i 's/640/320/g' /usr/local/share/start_camera_stream.sh
sudo sed -i 's/480/240/g' /usr/local/share/start_camera_stream.sh

chmod a+w /home/pi/usb_share/html_root/*php
cp -f /tmp/2_4_2_resources/html_root/* /home/pi/usb_share/html_root
chmod a-w /home/pi/usb_share/html_root/*php

sudo chown pi /home/pi/usb_share/flags/current_version.txt
sudo chgrp pi /home/pi/usb_share/flags/current_version.txt
chmod a+w /home/pi/usb_share/flags/current_version.txt
cp -f /tmp/2_4_2_resources/flags/current_version.txt /home/pi/usb_share/flags/current_version.txt

chmod a+w /home/pi/usb_share/html_root/includes/*php
cp -f /tmp/2_4_2_resources/includes/* /home/pi/usb_share/html_root/includes
chmod a-w /home/pi/usb_share/html_root/includes/*php

chmod a+w /home/pi/usb_share/html_root/css/*
cp -f /tmp/2_4_2_resources/css/* /home/pi/usb_share/html_root/css
chmod a-w /home/pi/usb_share/html_root/css/*

sudo cp -f /tmp/2_4_2_resources/usr_local_share/* /usr/local/share
sudo chmod 755 /usr/local/share/*sh
sudo chmod 755 /usr/local/share/*py

sudo cp -f /tmp/2_4_2_resources/usr_local_bin/upgrade_usb_share /usr/local/bin/upgrade_usb_share
sudo chmod 755 /usr/local/bin/upgrade_usb_share

sudo crontab /tmp/2_4_2_resources/etc/crontab