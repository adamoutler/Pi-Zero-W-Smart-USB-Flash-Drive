
<?php 
  $cmd = 'sudo /home/pi/.usb_share_resources/portal/scripts/mono_x_action.py ' . $_GET['action'];
  $command = escapeshellcmd($cmd);
  $output = shell_exec($command);
  echo $output
?>