<?php 
    $cmd = "sudo upgrade_usb_share;";
    shell_exec($cmd);
?>