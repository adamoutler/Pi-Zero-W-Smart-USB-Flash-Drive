<?php 
# get usb stroage sizes
$current_usb_size = shell_exec('/home/pi/.usb_share_resources/portal/scripts/rpi_usb_disk_mgmt.py -u');
$max_usb_size = exec('/home/pi/.usb_share_resources/portal/scripts/rpi_usb_disk_mgmt.py -m');
$avail_disk_space = exec('/home/pi/.usb_share_resources/portal/scripts/rpi_usb_disk_mgmt.py -a');
$new_usb_size = strtolower($_POST["new_usb_size"]);

$est_sec = $new_usb_size * 130;
$est_h_m_s = secToHR($est_sec);

function secToHR($seconds) {
    $hours = floor($seconds / 3600);
    $minutes = floor(($seconds / 60) % 60);
    $seconds = $seconds % 60;
    return "$minutes:$seconds";
  }

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Troy Smith">

    <title>USB Share Management Console : Rebuild USB Storage</title>

    

    <!-- Bootstrap core CSS -->
<link href="/css/bootstrap.min.css" rel="stylesheet">

    <style>
        .progress_row {
            padding: 1em 1em 1em 0;
        }

        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="/css/dashboard.css" rel="stylesheet">

    <link rel="preload" href="/img/progress.gif" as="image">
    <link rel="preload" href="/img/bootstrap-icons/check2-circle.svg" as="image">
  </head>
  <body >
    <header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
    <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="/index.php"><?php echo strtoupper(gethostname());?></a>
    <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    </header>

    <div class="container-fluid">
    <div class="row">
        <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
        </nav>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2"><img src="/img/usb.png" style="height:1.5em;"> Rebuild USB Storage</h1>
            </div>
            <table>
                <tr>
                    <td>SD Card Free Space:</td>
                    <td><?php echo $avail_disk_space, " GB"; ?></td>
                </tr>
                <tr>
                    <td>Current USB Storage:</td>
                    <td><?php echo $current_usb_size, " GB"; ?></td>
                </tr>
                
                <tr>
                    <td style="padding-right:1em;">Adjusted USB Storage:</td>
                    <td><?php echo number_format($new_usb_size, 2, '.', ''), " GB"; ?></td>
                </tr>
            </table>
<?php echo $progress_str; ?>
            <h4 style="margin-top:2em;">Progress</h4>
            <table>
                <tr>
                    <td class="progress_row">Stop services</td>
                    <td ><p id="progress_stop_services"></p></td>
                </tr>
                <tr>
                    <td class="progress_row">Delete existing USB storage</td>
                    <td ><p id="progress_delete_usb"></p></td>
                </tr> 
                <tr>
                    <td class="progress_row">Create New USB Storage<br><span style="color:#ccc;">Estimated duration: <?php echo $est_h_m_s; ?></span></td>
                    <td><p id="progress_create_usb"></p><p id="prcnt_complete" style="font-size:1.5em;"></p></td>
                </tr> 
                <tr>
                    <td class="progress_row">Create file system</td>
                    <td><p id="progress_create_fs"></p></td>
                </tr> 
                <tr>
                    <td class="progress_row">Start services</td>
                    <td><p id="progress_start_services"></p></td>
                </tr>  
                <tr>
                    <td class="progress_row">Reboot</td>
                    <td><p id="progress_reboot"></p></td>
                </tr>    
            </table>

        </main>
    </div>
    </div>
    <script src="/js/bootstrap.bundle.min.js"></script>
    <script>
        new_img_size = <?php echo ($new_usb_size * 1024), ';'; ?>
        function setStatus(ctl,val) {
            var control = ctl;
            var status = val;

            if(status == "not started") {
                document.getElementById(control).innerHTML = "";
            } 
            else if (status == "in progress") {
                document.getElementById(control).innerHTML = "<img src='/img/progress.gif' style='height:2em;'>";
            } 
            else if (status == "complete") {
                document.getElementById(control).innerHTML = "<img src='/img/bootstrap-icons/check2-circle.svg' class='icon'  style='height:2em;'>";
            }
            else 
            {
                document.getElementById(control).innerHTML = status;
            }
        }

        function startRebuild() {
            let req = new XMLHttpRequest();
            url = "/includes/rebuild_usb_disk_action.php?usb_size=<?php echo $new_usb_size; ?>";

            req.open('GET', url, true);
            req.onload = function() {
                if (req.status == 200) {
                    getStatus();
                }
            }
            req.send();
        }

        function getStatus(setProgress) {

            let req = new XMLHttpRequest();
            req.open('GET', "/includes/rebuild_usb_disk_action.php?get_status");
            req.onload = function() {
                if (req.status == 200) {
                    var progress = this.responseText.trim();

                    if(progress == "stop_services")
                    {
                        setStatus("progress_stop_services", "in progress");
                        setStatus("progress_delete_usb", "not started");
                        setStatus("progress_create_usb", "not started");
                        setStatus("prcnt_complete", "");
                        setStatus("progress_create_fs", "not started");
                        setStatus("progress_start_services", "not started");
                        setStatus("progress_reboot", "not started");
                    }
                    else if(progress == "delete_image")
                    {
                        setStatus("progress_stop_services", "complete");
                        setStatus("progress_delete_usb", "in progress");
                        setStatus("progress_create_usb", "not started");
                        setStatus("prcnt_complete", "");
                        setStatus("progress_create_fs", "not started");
                        setStatus("progress_start_services", "not started");
                        setStatus("progress_reboot", "not started");
                    }
                    else if(progress == "create_image")
                    {
                        setStatus("progress_stop_services", "complete");
                        setStatus("progress_delete_usb", "complete");
                        setStatus("progress_create_usb", "not started");
                        setStatus("progress_create_fs", "not started");
                        setStatus("progress_start_services", "not started");
                        setStatus("progress_reboot", "not started");

                        current_size = 0;
                        percent_copmplete = 0;
                        let req2 = new XMLHttpRequest();
                        url = "/includes/rebuild_usb_disk_action.php?get_disk_size";

                        req2.open('GET', url);
                        req2.onload = function() {
                            if (req2.status == 200) {
                                current_size = this.responseText.trim();

                                percent_copmplete = Math.floor((current_size / new_img_size) * 100);
                                $prcnt_img_complete = Math.floor((current_size / new_img_size) * 100);

                                setStatus("prcnt_complete", percent_copmplete+"%");
                            }
                        }
                        req2.send();
                    }
                    else if(progress == "create_fs")
                    {
                        setStatus("progress_stop_services", "complete");
                        setStatus("progress_delete_usb", "complete");
                        setStatus("progress_create_usb", "complete");
                        setStatus("prcnt_complete", "");
                        setStatus("progress_create_fs", "in progress");
                        setStatus("progress_start_services", "not started");
                        setStatus("progress_reboot", "not started");
                    }
                    else if(progress == "start_services")
                    {
                        setStatus("progress_stop_services", "complete");
                        setStatus("progress_delete_usb", "complete");
                        setStatus("progress_create_usb", "complete");
                        setStatus("prcnt_complete", "");
                        setStatus("progress_create_fs", "complete");
                        setStatus("progress_start_services", "in progress");
                        setStatus("progress_reboot", "not started");
                    }
                    else if(progress == "reboot")
                    {
                        setStatus("progress_stop_services", "complete");
                        setStatus("progress_delete_usb", "complete");
                        setStatus("progress_create_usb", "complete");
                        setStatus("prcnt_complete", "");
                        setStatus("progress_create_fs", "complete");
                        setStatus("progress_start_services", "complete");
                        setStatus("progress_reboot", "in progress");
alert("ready to reboot";)
                        let req2 = new XMLHttpRequest();
                        req2.open('GET', "/includes/rebuild_usb_disk_action.php?reboot");
                        req2.onload = function() {
                            if (req2.status == 200) {
                            }
                        }
                        req2.send();
                    }
                    else if(progress == "complete")
                    {
                        setStatus("progress_stop_services", "complete");
                        setStatus("progress_delete_usb", "complete");
                        setStatus("progress_create_usb", "complete");
                        setStatus("prcnt_complete", "");
                        setStatus("progress_create_fs", "complete");
                        setStatus("progress_start_services", "complete");
                        setStatus("progress_reboot", "in progress");


                        let req2 = new XMLHttpRequest();
                        url = "/settings.php";

                        req2.open('GET', url);
                        req2.onload = function() {
                            if (req2.status == 200) {
                                window.location.href = "/settings.php";
                            }
                        }
                        req2.send();  
                    }
                } 
            }
            req.send();
        }
        
        window.onload = function afterWebPageLoad() { 
            startRebuild();
            window.setInterval("getStatus();", 3000);
        } 
    </script>
  </body>
</html>
