<?php 
    $action = $_GET["action"];
    $new_usb_size = $_GET["usb_size"];

    if($action == 'stopServices') {
        $cmd = 
            'sudo touch /home/pi/.usb_share_resources/portal/rebuilding_usb;' .
            'sudo service smbd stop;' .
            'sudo modprobe -r g_mass_storage;' .
            'sudo umount /home/pi/USB_Share/upload;';
        shell_exec($cmd);
    } elseif($action == 'deleteUSB') {
        $cmd = 'sudo rm /home/pi/USB_Share/usbdisk.img;';
        shell_exec($cmd);
    } elseif($action == 'createUSB') {
        $size = $new_usb_size * 1024;
        $cmd = 'sudo dd bs=1M if=/dev/zero of=/home/pi/USB_Share/usbdisk.img count=' . $size . ';';
        shell_exec($cmd);
    } elseif($action == 'createFS') {
        $cmd = 'sudo mkdosfs /home/pi/USB_Share/usbdisk.img -F 32 -I;';
        shell_exec($cmd);
    } elseif($action == 'startServices') {
        $cmd = 'sudo mount -a;' . 
            'sudo modprobe g_mass_storage file=/home/pi/USB_Share/usbdisk.img stall=0 ro=0 removable=1;' . 
            'sudo service smbd start;' .
            'sudo rm -f /home/pi/.usb_share_resources/portal/rebuilding_usb;' ;
        shell_exec($cmd);
    } elseif($action == 'reboot') {
        $cmd = 'sudo reboot;';
        shell_exec($cmd);
    }
?>