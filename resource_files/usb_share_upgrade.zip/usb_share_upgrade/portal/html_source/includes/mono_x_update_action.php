<?php
    $submitButton = strtolower($_GET["submitButton"]);
    $printer_ip = strtolower($_GET["printer_ip"]);
    $enable_protection = $_GET["enable_print_protection"];
    $enable_wifi_file = $_GET["enable_wifi_file"];

    if($submitButton == 'update') {
        $cmd = '/home/pi/.usb_share_resources/portal/scripts/rpi_update_mono_x.py update --printer_ip ' . $printer_ip . ' --enable_wifi ' . $enable_wifi_file . ' --enable_protection ' . $enable_protection;
    } else {
        $cmd = '/home/pi/.usb_share_resources/portal/scripts/rpi_update_mono_x.py disable';
    }
    shell_exec($cmd);
    echo "<a href='/settings.php'>Return to setting...</a>"
?>
