<?php 
$ip_array = explode(" ",shell_exec('hostname -I'));
$ip_address = $ip_array[0];
$current_hostname = strtolower($_POST["current_hostname"]);
$new_hostname = strtolower($_POST["new_hostname"]);
$enable_camera = strtolower($_POST["enable_camera"]);
$rotation = strtolower($_POST["rotation"]);
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Troy Smith">

    <title>USB Share Management Console : Update Raspberry Pi</title>

    

    <!-- Bootstrap core CSS -->
<link href="/css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="/css/dashboard.css" rel="stylesheet">
  </head>
  <body >
    <header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
    <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="/index.php"><?php echo strtoupper(gethostname());?></a>
    <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    </header>

    <div class="container-fluid">
    <div class="row">
        <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
        </nav>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">System Rebooting</h1>
            </div>

            <h5>Your Raspberry Pi is now rebooting to apply your changes  <img src='/img/progress.gif' style='height:2em;'></h5>
            </br>

            <?php 
            if( $current_hostname != $new_hostname)
            {
              ?>
              Updated URLs: 
              <ul>
              <li><a href='http://<?php echo strtolower($_POST["new_hostname"]),'.local'; ?>'>http://<?php echo $new_hostname,'.local'; ?></a></li>
              <li><a href='http://<?php echo strtolower($_POST["new_hostname"]),'.local'; ?>'>http://<?php echo $ip_address; ?></a></li>
              </ul>
              <?php
            }

            if($enable_camera != 'on')
            {
              $enable_camera = 'off';
            }
   

            if( $current_hostname != $new_hostname)
            {
              $cmd = "/home/pi/.usb_share_resources/portal/scripts/rpi_update.py --current_hostname '" . $current_hostname . "' --new_hostname '" . $new_hostname . "' --enable_camera " . $enable_camera ." --rotation " . $rotation . ";";
              shell_exec($cmd);
            }
            else 
            {
              $cmd = "/home/pi/.usb_share_resources/portal/scripts/rpi_update.py --enable_camera " . $enable_camera ." --rotation " . $rotation . ";";
              shell_exec($cmd);
            }

            ?>

        </main>
    </div>
    </div>
    <script src="/js/bootstrap.bundle.min.js"></script>
    <script>
      window.setInterval("reloadPage();", 5000);

      function reloadPage() {
        let req = new XMLHttpRequest();
        req.open('GET', "/settings.php");
        req.onload = function() {
          if (req.status == 200) {
            window.location.href = "/settings.php";
          } 
        }
        req.send();
      }
    </script>
  </body>
</html>
