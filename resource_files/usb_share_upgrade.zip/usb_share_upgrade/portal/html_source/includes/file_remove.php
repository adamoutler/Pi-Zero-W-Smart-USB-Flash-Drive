<?php
    $file_name = strtolower($_GET["file"]);

    $cmd = "sudo rm -f /home/pi/USB_Share/upload/" . $file_name . ";";

    shell_exec($cmd);
    //echo $cmd;

    header( 'Location: /index.php' ) ;
?>