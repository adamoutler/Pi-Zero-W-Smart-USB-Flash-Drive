<?php
    $command = escapeshellcmd('/home/pi/.usb_share_resources/portal/scripts/mono_x_status.py');
    $output = shell_exec($command);
    $printer_details = json_decode(str_replace("'",'"',$output));
    $printer_files = $printer_details->files;
    $printer_ip_address = $printer_details->ip_address;
    $printer_status = $printer_details->printer_status;
    $print_job = explode('/',$printer_details->print_job);
    $layers_complete = $printer_details->layers_complete;
    $percent_complete = $printer_details->percent_complete;
    $seconds_remaining = (int) $printer_details->seconds_remaining;
    $resin_required = $printer_details->resin_required;
    $printer_connection = $printer_details->connection;
    
    echo json_encode($printer_details);
?>
