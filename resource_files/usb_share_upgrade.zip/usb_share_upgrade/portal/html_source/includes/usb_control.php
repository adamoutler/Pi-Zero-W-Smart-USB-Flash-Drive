<?php 
$submitButton = strtolower($_POST["submitButton"]);

$cmd = "/home/pi/.usb_share_resources/portal/scripts/rpi_usb_control.py --action '" . $submitButton . "';";
shell_exec($cmd);
header('Location: /controls.php');
?>