
<?php 
$_SESSION['pageClass'] = 'tools';
$current_hostname = strtolower(gethostname());
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Troy Smith">

    <title>USB Share Management Console : Power / Control</title>

    

    <!-- Bootstrap core CSS -->
<link href="css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="css/dashboard.css" rel="stylesheet">

    <style>
    input[type=text] {
      max-width: 200px;
    }
    </style>
  </head>
  <body >
   
<header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
  <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="/index.php"><?php echo strtoupper(gethostname());?></a>
  <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
</header>

<div class="container-fluid">
  <div class="row">
    <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
    <?php include 'includes/navigation.php';?>
    </nav>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"><img src="/img/rpi.png" style="max-width:2em;"> Raspberry Pi Power</h1>
    </div>

      <form action="/includes/shutdown_rpi.php" method="post" enctype="multipart/form-data" style="margin-top:2em;margin-bottom:4em;">
        <button type="submit" class="btn btn-warning" name="submitButton" value="reboot" style="width:10em;"><img src="/img/bootstrap-icons/bootstrap-reboot.svg" style="height:1.2em;"> Reboot</button>
        <button type="submit" class="btn btn-danger" name="submitButton" value="shutdown" style="width:10em;"><img src="/img/bootstrap-icons/power.svg" class="icon_white" style="height:1.3em;"> Shutdown</button>
      </form>

    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"><img src="/img/usb.png" style="max-width:2em;padding-right:.5em;"> USB Control</h1>
    </div>  
    <form action="/includes/usb_control.php" method="post" enctype="multipart/form-data" style="margin-top:2em;margin-bottom:4em;">
        <button type="submit" class="btn btn-primary" name="submitButton" value="reset" style="width:10em;"><img src="/img/bootstrap-icons/arrow-repeat.svg" class="icon_white" style="height:1.3em;"> Reset USB</button>
        <button type="submit" class="btn btn-primary" name="submitButton" value="unplug" style="width:10em;"><img src="/img/bootstrap-icons/box-arrow-up.svg" class="icon_white" style="height:1.2em;"> Unplug USB</button>
    </form>
    </main>
  </div>
</div>


    <script src="/js/bootstrap.bundle.min.js"></script>
    <script src="/js/jquery.min.js"></script>
  </body>
</html>
