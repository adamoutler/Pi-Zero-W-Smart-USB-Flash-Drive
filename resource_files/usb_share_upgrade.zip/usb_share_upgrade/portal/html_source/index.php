
<?php 
$_SESSION['pageClass'] = 'index';

function folderSize ($dir)
{
    $size = 0;

    foreach (glob(rtrim($dir, '/').'/*', GLOB_NOSORT) as $each) {
        $size += is_file($each) ? filesize($each) : folderSize($each);
    }

    return $size;
}

$upload_str = '/home/pi/USB_Share/upload/';
$disk_img = '/home/pi/USB_Share/usbdisk.img';

$cmd = 'stat -c %s /home/pi/USB_Share/usbdisk.img';
$disk_size_bytes = shell_exec($cmd);


$disk_size = abs($disk_size_bytes / 1024 / 1024 );
$disk_used = abs(folderSize($upload_str) / 1024 / 1024 );
$disk_free = $disk_size - $disk_used;


$ip_array = explode(" ",shell_exec('hostname -I'));
$ip_address = $ip_array[0];
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Troy Smith">
    <meta http-equiv="refresh" content="30" >

    <title>USB Share Management Console : Summary</title>

    <!-- Bootstrap core CSS -->
    <link href="/css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="/css/dashboard.css" rel="stylesheet">
  </head>
  <body >
   
    <header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
      <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="/index.php"><?php echo strtoupper(gethostname());?></a>
      <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </header>

    <div class="container-fluid">
      <div class="row">
        <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
        <?php include 'includes/navigation.php';?>
        </nav>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2"><img src="img/rpi.png" style="height:2em;"> Raspberry Pi</h1>
          </div>
          <table style='margin-bottom:1em;'>
          <tbody>
                <tr><td style='padding-right:2em;'><strong>Hostname: </strong></td><td><strong><?php echo strtoupper(gethostname());?></strong></td></tr>
                <tr><td style='padding-right:2em;'>Bonjour Name: </td><td><?php echo strtolower(gethostname()), '.local';
                
                if(strpos(strtolower($_SERVER['HTTP_USER_AGENT']),'windows') !== false)
                {
                  echo '  (<a target="_new" href="https://support.apple.com/kb/DL999?locale=en_US">Windows Installer</a>)';
                }
                
                ?>
                  
                  </td></tr>
                <tr><td style='padding-right:2em;'>IP Address: </td><td><?php echo $ip_address;?></td></tr>

                <tr><td style='padding-right:2em;vertical-align: top;'>Model: </td><td><?php echo nl2br(shell_exec('cat /proc/device-tree/model')); ?></td></tr>
                <tr><td style='padding-right:2em;vertical-align: top;'>OS: </td><td style='padding-bottom:1em;vertical-align: top;'><?php 
                    $new_array = explode("\n", shell_exec('lsb_release -a'));
                    echo str_replace('Description:','',$new_array[1]);
                ?></td></tr>
              </tbody>
            </table>

        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2"><img src="/img/bootstrap-icons/share.svg" style="height:1.6em;"> Network Share Paths</h1>
        </div>
            <h6>MacOS</h6>
            <ul>
                <?php 
                echo '<li>The Raspberry Pi will show up in the Finder sidebar. Look for <strong>',gethostname(), '</strong> in the network list.</li>';
                echo '<li>Alternatively, from the Finder menu, select Go Connect to server (Apple key + K) and type <strong>smb://', gethostname(), '</strong> as the server address.</li>';
                ?>
            </ul>
            </br>
            <h6>Windows</h6>
            Bring up Explorer (Windows key + E) and type one of the following into the address bar at the top. The Run dialogue also works (Windows key + R).
            <ul>
                <li>\\<?php echo $ip_address;?>\usb</li>
                <li>\\<?php echo strtolower(gethostname()), '.local'; ?>\usb  
                <?php             
                if(strpos(strtolower($_SERVER['HTTP_USER_AGENT']),'windows') !== false)
                {
                  echo '  (<a target="_new" href="https://support.apple.com/kb/DL999?locale=en_US">Windows Installer</a>)';
                }
                
                ?></li>
            </ul>

          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2"><img src="img/usb.png" style="height:2em;"> USB Storage</h1>
          </div>
          <?php 
          if(file_exists('/home/pi/.usb_share_resources/portal/rebuilding_usb'))
          {
            ?>

            <table style='margin-bottom:2em;'>
              <tbody>
                <tr><td style='padding-right:2em;'><strong>USB Storage: </strong></td><td><strong>Rebuilding <img src='/img/progress.gif' style='height:2em;'></td></tr>
                <tr><td style='padding-right:2em;'>Used: </td><td></td></tr>
                <tr><td style='padding-right:2em;'>Free: </td><td></td></tr>
              </tbody>
            </table>

            <?php

          } else 
          {
            ?>

            <table style='margin-bottom:2em;'>
              <tbody>
                <tr><td style='padding-right:2em;'><strong>USB Storage: </strong></td><td><strong><?php echo number_format(($disk_size / 1024),2);?> GB</strong></td></tr>
                <tr><td style='padding-right:2em;'>Used: </td><td><?php echo number_format($disk_used,2);?> MB</td></tr>
                <tr><td style='padding-right:2em;'>Free: </td><td><?php echo number_format($disk_free,2);?> MB</td></tr>
              </tbody>
            </table>

            <?php
            if(file_exists('/home/pi/.usb_share_resources/portal/enable_mono_x'))
            {
              $command = escapeshellcmd('/home/pi/.usb_share_resources/portal/scripts/mono_x_status.py');
              $output = shell_exec($command);
              $printer_details = json_decode(str_replace("'",'"',$output));
  
              $printer_status = $printer_details->printer_status;

              if($printer_status == "Stopped")
              {
              ?>
                <form action="/includes/upload.php" method="post" enctype="multipart/form-data">
                  <table >
                    <tr>
                      <td style="padding-left:2em;background-color: #ccc;padding:.4em;border-top-left-radius: .4em;border-bottom-left-radius: .4em;"><input type="file" name="fileToUpload" id="fileToUpload"></td>
                      <td style="text-aligh:right;"><input type="submit" value="Upload File" name="submit" class="btn btn-primary" style="border-top-left-radius:0;border-bottom-left-radius:0;"></td>
                    </tr>
                  </table>
                </form>
              <?php
              }
              else 
              {
                ?>
                  <table >
                    <tr>
                      <td style="padding-left:2em;background-color: #ccc;padding:.4em;border-top-left-radius: .4em;border-bottom-left-radius: .4em;"><input type="file" name="fileToUpload" id="fileToUpload" disabled="true"></td>
                      <td style="text-aligh:right;"><input type="submit" value="Upload File" name="submit" class="btn btn-primary" style="border-top-left-radius:0;border-bottom-left-radius:0;" disabled="true"></td>
                      <td> -- Disabled while printing
                    </tr>
                  </table>
              <?php
              }

            }
            else 
            {
              ?>
              <form action="/includes/upload.php" method="post" enctype="multipart/form-data">
                <table >
                  <tr>
                    <td style="padding-left:2em;background-color: #ccc;padding:.4em;border-top-left-radius: .4em;border-bottom-left-radius: .4em;"><input type="file" name="fileToUpload" id="fileToUpload"></td>
                    <td style="text-aligh:right;"><input type="submit" value="Upload File" name="submit" class="btn btn-primary" style="border-top-left-radius:0;border-bottom-left-radius:0;"></td>
                  </tr>
                </table>
              </form>

              <?php
            }
            ?>
              <div class="table-responsive">
                <table class="table table-striped table-sm" style="margin-bottom:4em;">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Size</th>
                      <th>Modified</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php

                  $fileList = glob($upload_str . '*');
                  sort($fileList);

                  foreach($fileList as $filename){
                    if(str_replace($upload_str,"",$filename) != "history.bin")
                    {
                      echo '<tr>';
                      echo '<td>',str_replace($upload_str,"",$filename), '</td>';
                      echo '<td>',number_format((filesize($filename) / 1024 / 1024),2), ' MB</td>';
                      echo '<td>',date("F d, Y H:i:s",filemtime($filename)), '</td>';
                      echo "<td><a href=/includes/file_remove.php?file='" . urlencode (str_replace($upload_str,"",$filename)) . "'><img src='/img/trash.svg'></a></td>";
                      echo '</tr>';
                    }
                  }
                  ?>
                  </tbody>
                </table>

              </div>
            <?php

          }

          ?>

          
        </main>
      </div>
    </div>
    <script src="/js/bootstrap.bundle.min.js"></script>
    <script src="/js/jquery.min.js"></script>
  </body>
</html>
