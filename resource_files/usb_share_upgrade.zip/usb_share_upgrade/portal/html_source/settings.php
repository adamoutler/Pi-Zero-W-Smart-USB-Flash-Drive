
<?php 
$_SESSION['pageClass'] = 'settings';
$current_hostname = strtolower(gethostname());

# get usb stroage sizes
$current_usb_size = shell_exec('/home/pi/.usb_share_resources/portal/scripts/rpi_usb_disk_mgmt.py -u');
$max_usb_size = exec('/home/pi/.usb_share_resources/portal/scripts/rpi_usb_disk_mgmt.py -m');
$avail_disk_space = exec('/home/pi/.usb_share_resources/portal/scripts/rpi_usb_disk_mgmt.py -a');
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Troy Smith">

    <title>USB Share Management Console : Settings</title>

    

    <!-- Bootstrap core CSS -->
<link href="css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="css/dashboard.css" rel="stylesheet">

    <style>
    input[type=text] {
      max-width: 200px;
    }
    </style>
  </head>
  <body >
   
<header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
  <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="/index.php"><?php echo strtoupper(gethostname());?></a>
  <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
</header>

<div class="container-fluid">
  <div class="row">
    <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
    <?php include 'includes/navigation.php';?>
    </nav>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"><img src="/img/bootstrap-icons/sliders.svg" style="height:1.2em;"> Settings</h1>
        <?php 
        $current_version = "";
        $local_version = "0.0.0";

        try {
          $current_version = file_get_contents('https://raw.githubusercontent.com/tds2021/Pi-Zero-W-Smart-USB-Flash-Drive/main/resource_files/current_version.txt');
        } catch (exception $e) { }

        try {
          $local_version = file_get_contents('/home/pi/.usb_share_resources/portal/current_version.txt', true);
        } catch (exception $e) { }
        
        if(trim($current_version) != trim($local_version))
        {
        ?>
          <form class = "form-inline" role="form" method="post" enctype="multipart/form-data" action="/includes/upgrade_portal.php">
            <button type="submit" class="btn btn-warning">Upgrade to Version: <?php echo $current_version; ?></button>
          </form>
        <?php
        } 
        ?>
      </div>


      <h4 style="border-bottom:1px solid #ccc;padding-bottom:.25em;margin-bottom:.75em;max-width:400px"><img src="img/rpi.png" style="height:1.5em;"> Raspberry Pi</h4>
      <form class = "form-inline" role="form" method="post" enctype="multipart/form-data" action="/includes/update_rpi.php" style="padding-bottom:4em;">
        <table>
          <tr>
            <td style="width:8em;"><label class = "sr-only" for = "name"><span style="font-size:1.5em;">Hostname: </span></label></td>
            <td>
              <input type = "hidden" id = "current_hostname" name= "current_hostname" value = "<?php echo strtoupper(gethostname());?>">
              <input type = "text" id = "new_hostname" name= "new_hostname"  value= "<?php echo strtoupper(gethostname());?>" class = "form-control" required="true">
            </td>
           
          </tr>
          <tr>
            <td colspan="2">
              <div class="checkbox" style="margin-top:1em;">
                  <label><input type="checkbox" id="enable_camera"  name="enable_camera"
                  <?php if(file_exists('/home/pi/.usb_share_resources/portal/enable_camera'))
                    {
                      echo ' checked';
                    }
                  ?>
                  > Enable Camera Support</label>
            </td>
          </tr>
          <tr>
             <td colspan="2" style="padding-left:2em;"> 
                    <table>
                      <tr>
                        <td>Rotate: </td>
                        <td>
                          <select name="rotation" id="rotation">
                            <option value="0" 
                            <?php if(file_exists('/home/pi/.usb_share_resources/portal/rotate_0'))
                              {
                                echo ' selected';
                              }
                            ?>>No Rotation</option>
                            <option value="90"
                            <?php if(file_exists('/home/pi/.usb_share_resources/portal/rotate_90'))
                              {
                                echo ' selected';
                              }
                            ?>
                            >90&deg;</option>
                                      <option value="180"
                            <?php if(file_exists('/home/pi/.usb_share_resources/portal/rotate_180'))
                              {
                                echo ' selected';
                              }
                            ?>
                            >180&deg;</option>
                                      <option value="270"
                            <?php if(file_exists('/home/pi/.usb_share_resources/portal/rotate_270'))
                              {
                                echo ' selected';
                              }
                            ?>
                            >270&deg;</option>
                          </select>
                        </td>
                      </tr>
                    </table>
             </td>
          <tr>
          <td style="padding-top:1em;vertical-align:middle;"><button type="submit" class="btn btn-primary">Update</button></td>
          <td colspan="2" style="padding-top:1em;vertical-align:middle;"> Note: The system will reboot<br>for changes to take effect.</td>
          </tr>
        </table>
      </form>

      <h4 style="border-bottom:1px solid #ccc;padding-bottom:.25em;margin-bottom:.75em;max-width:400px"><img src="img/usb.png" style="height:1.5em;"> USB Storage</h4>

      <?php 
          if(file_exists('/home/pi/.usb_share_resources/portal/rebuilding_usb'))
          {
            ?>
            <div style="padding-bottom:4em;">
              <table>
                <tr><td>SD Card Free Space:</td><td>Rebuilding <img src='/img/progress.gif' style='height:2em;'></td></tr>
                <tr><td>Current USB Storage:</td><td></td></tr>
                <tr><td style="padding:1em 0 1em 0;padding-right:1em;">Adjusted USB Storage:</td><td style="padding:1em 0 1em 0;"></td></tr>
              </table>
            </div>
            <?php

          } else 
          {
            ?>
            <form class = "form-inline" role="form" method="post" enctype="multipart/form-data" action="/includes/rebuild_usb_disk.php" style="padding-bottom:4em;">
              <table>
                <tr><td>SD Card Free Space:</td><td><?php echo $avail_disk_space, " GB"; ?></td></tr>
                <tr><td>Current USB Storage:</td><td><?php echo $current_usb_size, " GB"; ?></td></tr>
                <tr><td style="padding:1em 0 1em 0;padding-right:1em;">Adjusted USB Storage:</td><td style="padding:1em 0 1em 0;">
                  <select name="new_usb_size" id="new_usb_size">
                    <?php 

                      for($i = 1; $i <= (int) $max_usb_size; $i++)
                      {
                        if($i == $current_usb_size) {
                          echo "<option value='", $i, "' selected='true'>", $i, " GB</option>";
                        }
                        else {
                          echo "<option value='", $i, "'>", $i, " GB</option>";
                        }
                        
                      }
                    ?>
                  </select>
                  </td></tr>
                <tr><td colspan="2"><button type="submit" class="btn btn-primary">Rebuild USB Storage</button></td></tr>
              </table>
            </form>
            <?php
          }

          if(file_exists('/home/pi/.usb_share_resources/portal/enable_mono_x'))
          {
            ?>
            <div>
            <h4 style="border-bottom:1px solid #ccc;padding-bottom:.25em;margin-bottom:.75em;max-width:400px"><img src="img/PhotonMonoX.jpg" style="max-width:1.75em;filter: grayscale(.5);"> ANYCUBIC Mono X Support</h4>
            <form action="/includes/mono_x_update.php" method="post" enctype="multipart/form-data">

            <table>
              <tr>
                <td style="width:8em;"><label class = "sr-only" for = "printer_ip"><span style="font-size:1.5em;">Printer IP: </span></label></td>
                <td>
                  <input type = "text" id = "printer_ip" name= "printer_ip"  placeholder = "###.###.###.###" 
                    <?php if(file_exists('/home/pi/.usb_share_resources/portal/printer_ip'))
                    {
                      echo 'value="' .file_get_contents("/home/pi/.usb_share_resources/portal/printer_ip") . '"';
                    }
                  ?>
                   class = "form-control">
                </td>
              </tr>
              <tr>
                <td colspan='2'>
                <div class="checkbox" style="margin-top:1em;">
                  <label><input type="checkbox" id="enable_print_protection" name="enable_print_protection" checked=true disabled=true > Enable Print Protection</label>
                </div>

                <div class="checkbox" style="margin-top:1em;">
                  <label><input type="checkbox" id="enable_wifi_file"  name="enable_wifi_file"
                  <?php if(file_exists('/home/pi/.usb_share_resources/portal/enable_wifi_file'))
                    {
                      echo ' checked';
                    }
                  ?>
                  
                  > Enable WiFi.txt file creation</label>
                </div>
                </td>
              </tr>
              <tr>
                <td colspan='2' style="padding-top:1em;">
                  <button type="submit" class="btn btn-primary" name="submitButton" value="update">Update</button>
                  <button type="submit" class="btn btn-warning" name="submitButton" value="disable">Disable Mono X Support</button>
                </td>
            </table>
            </form>
            </div>
          <?php
          }
          else 
          {
          ?>
            <div>
            <h4 style="border-bottom:1px solid #ccc;padding-bottom:.25em;margin-bottom:.75em;max-width:400px"><img src="img/PhotonMonoX.jpg" style="max-width:1.75em;filter: grayscale(.5);"> ANYCUBIC Mono X Support</h4>
            <form class = "form-inline" role="form" method="post" enctype="multipart/form-data" action="/includes/mono_x_enable.php">
            <button type="submit" class="btn btn-primary">Enable Mono X Support</button>
            </form>
            </div>
          <?php
          }
          ?>



    </main>
  </div>
</div>


    <script src="/js/bootstrap.bundle.min.js"></script>
    <script src="/js/jquery.min.js"></script>
  </body>
</html>
