#!/usr/bin/env python3

import os
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("--action")

args = parser.parse_args()

action = str(args.action)


if action == 'reset':
    os.system("sudo modprobe -r g_mass_storage;")
    os.system("sudo modprobe g_mass_storage file=/home/pi/USB_Share/usbdisk.img stall=0 ro=0 removable=1;")
elif action == 'unplug':
    os.system("sudo modprobe -r g_mass_storage;")
