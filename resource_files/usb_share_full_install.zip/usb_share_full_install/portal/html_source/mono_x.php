
<?php 
$_SESSION['pageClass'] = 'mono_x';
$ip_array = explode(" ",shell_exec('hostname -I'));
$ip_address = $ip_array[0];

$command = escapeshellcmd('/home/pi/.usb_share_resources/portal/scripts/mono_x_status.py');
$output = shell_exec($command);
$printer_details = json_decode(str_replace("'",'"',$output));
$printer_files = $printer_details->files;
$printer_ip_address = $printer_details->ip_address;
$printer_status = $printer_details->printer_status;
$print_job = explode('/',$printer_details->print_job);
$layers_complete = $printer_details->layers_complete;
$percent_complete = $printer_details->percent_complete;
$seconds_remaining = (int) $printer_details->seconds_remaining;
$resin_required = $printer_details->resin_required;
$printer_connection = $printer_details->connection;
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Troy Smith">
    <meta http-equiv="refresh" content="10" >

    <title>USB Share Management Console : Mono X Control</title>

    <!-- Bootstrap core CSS -->
    <link href="/css/bootstrap.min.css" rel="stylesheet">


    
    <!-- Custom styles for this template -->
    <link href="/css/dashboard.css" rel="stylesheet">
  </head>
  <body >
   
    <header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
      <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="/index.php"><?php echo strtoupper(gethostname());?></a>
      <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </header>

    <div class="container-fluid">
      <div class="row">
        <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
        <?php include 'includes/navigation.php';?>
        </nav>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><img src="img/PhotonMonoX.jpg" style="max-width:2em;filter: grayscale(.5);"> ANYCUBIC Mono X</h1>
            </div>

            <div style="float: left; width:350px;margin-right:2em;">
            <table style='margin-bottom:2em;'>
              <tbody>
                <tr><td style='padding-right:2em;vertical-align: top;'>Printer&nbsp;IP: </td><td><?php echo $printer_ip_address; ?></td></tr>
                <tr><td style='padding-right:2em;vertical-align: top;'>Connection: </td><td><?php echo $printer_connection; ?></td></tr>
                <tr><td style='padding-right:2em;padding-bottom:1em;vertical-align: top;'>Status: </td><td style='padding-bottom:1em;vertical-align: top;'><?php echo $printer_status; ?></td></tr>


                <?php
                if($printer_status == "Printing")
                  {
                  ?>               
                  <tr><td style='padding-right:2em;vertical-align: top;'>Print&nbsp;Job: </td><td><?php echo $print_job[0]; ?></td></tr>
                  <tr><td style='padding-right:2em;padding-bottom:1em;vertical-align: top;'>Resin&nbsp;Required: </td><td style='padding-bottom:1em;vertical-align: top;'><?php echo $resin_required; ?></td></tr>
                  <tr><td style='padding-right:2em;vertical-align: top;'>Progress: </td><td><?php echo $percent_complete; ?></td></tr>
                  <tr><td style='padding-right:2em;vertical-align: top;'>Layers: </td><td><?php echo $layers_complete; ?></td></tr>
                  <tr><td style='padding-right:2em;vertical-align: top;'>Time&nbsp;Remaining: </td><td><?php echo gmdate("H:i:s", $seconds_remaining); ?></td></tr>
                <tr><td colspan='2'>
                  <img id="pausePrinting" name="pausePrinting" type="image" src='/img/pause-circle.svg' class='icon icon_lg'>
                  <img id="stopPrinting" name="stopPrinting" type="image" src='/img/stop-circle.svg' class='icon icon_lg'>
                </td></tr>
                  <?php
                  }
                  elseif ($printer_status == "Paused") {
                  ?>
                <tr><td colspan='2'>
                  <img id="resumePrinting" name="resumePrinting" type="image" src='/img/play-circle.svg' class='icon icon_lg'>
                </td></tr>
                  <?php
                  }
                  ?>

              </tbody>
            </table>
            </div>

            <?php 
            if(file_exists('/home/pi/.usb_share_resources/portal/enable_camera'))
            {
              ?>
                <div style="float: left;width:350px;">
                <img id="videoStream" src="http://<?php echo $ip_address ?>:8080/?action=stream" style="max-width:350px;">
                <p>Note: Image reloades every 30 sec to release browser memory.</p>
                </div>
            <?php
            }
            ?>

            <div style="clear:both;">

            <p id="status"></p>

            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
              <h1 class="h2"><img src="/img/bootstrap-icons/printer.svg" style="height:1.2em;"> Printer Files</h1>
            </div>

            <div class="table-responsive">
            <table class="table table-striped table-sm" style="margin-bottom:4em;">
              <thead>
              <tr>
              <th>File</th>
              <th style="text-align:center;"><span style="font-size:.7em;line-height:.25;">Start<br>Print</span></th>
              </tr>
              </thead>
              <tbody>
              <?php
              $fileList = explode(",",$printer_files);

              sort($fileList);
              foreach ($fileList as $key => $val) {
                $fileNames = explode("/",$val);

                if (strpos(strtolower($fileNames[0]), '.pwmx') !== false)
                {
                  echo '<tr>';
                  echo '<td>', $fileNames[0], '</td>';

                  if($printer_status == "Stopped")
                    {
                      echo '<td style="text-align:center;"><img id="startPrinting' . $key . '" name="startPrinting' . $key . '" type="image" src="/img/play-circle.svg" class="icon icon_sm"></td>';
                    }
                  else
                    {
                      echo '<td style="text-align:center;"></td>';
                    }

                  echo '</tr>';
                }
              }

              ?>
              </tbody>
            </table>
          </div>
        </main>
      </div>
    </div>

    <script src="/js/bootstrap.bundle.min.js"></script>
    <script src="/js/jquery.min.js"></script>

    <script>

      function pausePrinting()
      {
        monoXControl(myDisplayer,'pause'); 
      }
      function resumePrinting()
      {
        monoXControl(myDisplayer,'resume'); 
      }
      function stopPrinting()
      {
        monoXControl(myDisplayer,'stop'); 
      }

      function myDisplayer(some) {
        document.getElementById("status").innerHTML = some;
      }

      function monoXControl(myCallback, action) {
        let req = new XMLHttpRequest();
        req.open('GET', "/includes/mono_x_contol.php?action=" + action);
        req.onload = function() {
          if (req.status == 200) {
            myCallback(this.responseText);
            sleep(6000);
            window.location.reload(true);
          } else {
            myCallback("Error: " + this.responseText);
          }
        }
        req.send();
      }

      function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
      }

      <?php
              if($printer_status == "Stopped")
              {
                $fileList = explode(",",$printer_files);
                sort($fileList);

                foreach ($fileList as $key => $val) {
                  $fileNames = explode("/",$val);

                  if (strpos(strtolower($fileNames[0]), '.pwmx') !== false)
                  {
                    echo '
                    function startPrinting' . $key . '() {
                      action = \'print,' . $fileNames[1] . '\';
                      monoXControl(myDisplayer,action);
                    }
                    document.getElementById("startPrinting' . $key . '").addEventListener("click", startPrinting' . $key . ');
                    ';
                  }
                }

                if(file_exists('/home/pi/USB_Share/upload/WIFI.txt'))
                {
                  echo '
                  function startPrintingWiFi() {
                    action = \'print,WIFI.txt\';
                    monoXControl(myDisplayer,action);
                  }
                  document.getElementById("startPrintingWiFi").addEventListener("click", startPrintingWiFi);
                  ';
                }
              }
              elseif($printer_status == "Printing")
                {
                  ?>
                  document.getElementById("pausePrinting").addEventListener("click", pausePrinting);
                  document.getElementById("stopPrinting").addEventListener("click", stopPrinting);
                  <?php
                }
              elseif($printer_status == "Paused")
                {
                  ?>
                  document.getElementById("resumePrinting").addEventListener("click", resumePrinting);
                  <?php
                }
      ?>

        window.setInterval("reloadIMG();", 30000);

        function reloadIMG() {
          var temp = "http://<?php echo $ip_address ?>:8080/?action=stream&" + new Date().getTime();
          newImage = new Image();
          newImage.src = temp;
          document.getElementById("videoStream").src = newImage.src;
        }
      </script>

  </body>
</html>

