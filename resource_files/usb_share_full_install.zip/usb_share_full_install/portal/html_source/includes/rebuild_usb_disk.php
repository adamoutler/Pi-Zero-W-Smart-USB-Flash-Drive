<?php 
# get usb stroage sizes
$current_usb_size = shell_exec('/home/pi/.usb_share_resources/portal/scripts/rpi_usb_disk_mgmt.py -u');
$max_usb_size = exec('/home/pi/.usb_share_resources/portal/scripts/rpi_usb_disk_mgmt.py -m');
$avail_disk_space = exec('/home/pi/.usb_share_resources/portal/scripts/rpi_usb_disk_mgmt.py -a');
$new_usb_size = strtolower($_POST["new_usb_size"]);

$est_sec = $new_usb_size * 130;
$est_h_m_s = secToHR($est_sec);

function secToHR($seconds) {
    $hours = floor($seconds / 3600);
    $minutes = floor(($seconds / 60) % 60);
    $seconds = $seconds % 60;
    return "$minutes:$seconds";
  }

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Troy Smith">

    <title>USB Share Management Console : Rebuild USB Storage</title>

    

    <!-- Bootstrap core CSS -->
<link href="/css/bootstrap.min.css" rel="stylesheet">

    <style>
        .progress_row {
            padding: 1em 1em 1em 0;
        }

        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="/css/dashboard.css" rel="stylesheet">
  </head>
  <body >
    <header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
    <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="/index.php"><?php echo strtoupper(gethostname());?></a>
    <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    </header>

    <div class="container-fluid">
    <div class="row">
        <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
        </nav>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2"><img src="/img/usb.png" style="height:1.5em;"> Rebuild USB Storage</h1>
            </div>
            <table>
                <tr>
                    <td>SD Card Free Space:</td>
                    <td><?php echo $avail_disk_space, " GB"; ?></td>
                </tr>
                <tr>
                    <td>Current USB Storage:</td>
                    <td><?php echo $current_usb_size, " GB"; ?></td>
                </tr>
                
                <tr>
                    <td style="padding-right:1em;">Adjusted USB Storage:</td>
                    <td><?php echo number_format($new_usb_size, 2, '.', ''), " GB"; ?></td>
                </tr>
            </table>

            <h4 style="margin-top:2em;">Progress</h4>
            <table>
                <tr>
                    <td class="progress_row">Stop services</td>
                    <td ><p id="progress_stop_services"></p></td>
                </tr>
                <tr>
                    <td class="progress_row">Delete existing USB storage</td>
                    <td ><p id="progress_delete_usb"></p></td>
                </tr> 
                <tr>
                    <td class="progress_row">Create New USB Storage<br><span style="color:#ccc;">Estimated duration: <?php echo $est_h_m_s; ?></span></td>
                    <td><p id="progress_create_usb"></p></td>
                </tr> 
                <tr>
                    <td class="progress_row">Create file system</td>
                    <td><p id="progress_create_fs"></p></td>
                </tr> 
                <tr>
                    <td class="progress_row">Start services</td>
                    <td><p id="progress_start_services"></p></td>
                </tr>  
                <tr>
                    <td class="progress_row">Reboot</td>
                    <td><p id="progress_reboot"></p></td>
                </tr>    
            </table>

        </main>
    </div>
    </div>
    <script src="/js/bootstrap.bundle.min.js"></script>
    <script>
        function stopServices() {
            document.getElementById("progress_stop_services").innerHTML = "<img src='/img/progress.gif' style='height:2em;'>";

            let req = new XMLHttpRequest();
            req.open('GET', "/includes/rebuild_usb_disk_action.php?action=stopServices", true);
            req.onload = function() {
                if (req.status == 200) {
                    document.getElementById("progress_stop_services").innerHTML = "<img src='/img/bootstrap-icons/check2-circle.svg' class='icon'  style='height:2em;'>";
                    deleteUSB();
                }
            }
            req.send();
        }
        function deleteUSB() {
            document.getElementById("progress_delete_usb").innerHTML = "<img src='/img/progress.gif' style='height:2em;'>";

            let req = new XMLHttpRequest();
            req.open('GET', "/includes/rebuild_usb_disk_action.php?action=deleteUSB", true);
            req.onload = function() {
                if (req.status == 200) {
                    document.getElementById("progress_delete_usb").innerHTML = "<img src='/img/bootstrap-icons/check2-circle.svg' class='icon' style='height:2em;'>";
                    createUSB();
                } 
            }
            req.send();
        }
        function createUSB() {
            document.getElementById("progress_create_usb").innerHTML = "<img src='/img/progress.gif' style='height:2em;'>";

            let req = new XMLHttpRequest();
            req.open('GET', "/includes/rebuild_usb_disk_action.php?action=createUSB&usb_size=<?php echo $new_usb_size; ?>", true);
            req.timeout = 8000000;
            req.onload = function() {
                if (req.status == 200) {
                    document.getElementById("progress_create_usb").innerHTML = "<img src='/img/bootstrap-icons/check2-circle.svg' class='icon' style='height:2em;'>";
                    createFS();
                }
            }
            req.send();
        }
        function createFS() {
            document.getElementById("progress_create_fs").innerHTML = "<img src='/img/progress.gif' style='height:2em;'>";

            let req = new XMLHttpRequest();
            req.open('GET', "/includes/rebuild_usb_disk_action.php?action=createFS", true);
            req.onload = function() {
                if (req.status == 200) {
                    document.getElementById("progress_create_fs").innerHTML = "<img src='/img/bootstrap-icons/check2-circle.svg' class='icon' style='height:2em;'>";
                    startServices();
                }
            }
            req.send();
        }
        function startServices() {
            document.getElementById("progress_start_services").innerHTML = "<img src='/img/progress.gif' style='height:2em;'>";

            let req = new XMLHttpRequest();
            req.open('GET', "/includes/rebuild_usb_disk_action.php?action=startServices", true);
            req.onload = function() {
                if (req.status == 200) {
                    document.getElementById("progress_start_services").innerHTML = "<img src='/img/bootstrap-icons/check2-circle.svg' class='icon' style='height:2em;'>";
                    reboot();
                } 
            }
            req.send();
        }
        function reboot() {
            document.getElementById("progress_reboot").innerHTML = "<img src='/img/progress.gif' style='height:2em;'>";

            let req = new XMLHttpRequest();
            req.open('GET', "/includes/rebuild_usb_disk_action.php?action=reboot", true);
            req.onload = function() {
                if (req.status == 200) {
                    window.setInterval("reloadPage();", 5000);
                } 
            }
            req.send();
        }
        function reloadPage() {
            document.getElementById("progress_reboot").innerHTML = "<img src='/img/progress.gif' style='height:2em;'>";

            let req = new XMLHttpRequest();
            req.open('GET', "/settings.php");
            req.onload = function() {
                if (req.status == 200) {
                    window.location.href = "/settings.php";
                } 
            }
            req.send();
        }
        window.onload = function afterWebPageLoad() { 
            stopServices();
        } 
    </script>
  </body>
</html>
