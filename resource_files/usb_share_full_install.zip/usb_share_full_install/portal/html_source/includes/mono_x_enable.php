<?php
    shell_exec('/home/pi/.usb_share_resources/portal/scripts/rpi_update_mono_x.py enable;');
    header( 'Location: /settings.php' ) ;
?>
