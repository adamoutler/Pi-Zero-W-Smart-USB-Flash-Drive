<?php 
    if (isset($_GET['usb_size'])) {
        $new_usb_size = $_GET["usb_size"];
        $cmd = 'sudo /home/pi/.usb_share_resources/portal/scripts/rpi_usb_disk_create.sh ' . $new_usb_size . '&';
        #echo ($cmd);
        shell_exec($cmd);
    } elseif (isset($_GET['get_status'])) {
        if(file_exists("/home/pi/.usb_share_resources/portal/rebuilding_usb"))
        {
            echo (file_get_contents("/home/pi/.usb_share_resources/portal/rebuilding_usb"));
        }
        else 
        {
            echo "complete";
        }
    } elseif (isset($_GET['get_disk_size'])) {
        $current_usb_size = shell_exec('/home/pi/.usb_share_resources/portal/scripts/rpi_usb_disk_mgmt.py -umb');
        echo $current_usb_size;
    }
    elseif (isset($_GET['reboot'])) {
        $cmd = 'sudo /home/pi/.usb_share_resources/portal/scripts/rpi_usb_disk_create.sh reboot';
        shell_exec($cmd);
    }
        
    
?>
