
<?php ?>

<table class="table table-striped table-sm">
  <thead>
    <tr>
      <th>IP Address</th>
      <th>MAC Address</th>
      <th>Vendor</th>
    </tr>
  </thead>
  <tbody>
    <?php 
        $array_list = explode("\n", shell_exec('sudo arp-scan -I wlan0 -l'));
        $list_length = count($array_list);

        for($i = 2;$i < ($list_length - 3); $i++) {
          $array_device = explode("\t",$array_list[$i]);
          $ip_array = explode(".",$array_device[0]);
          $device_arrary[] = array('IP' => $array_device[0], 'MAC Address' => $array_device[1], 'Vendor' => $array_device[2],'IP_BLOCK_1' => $ip_array [0],'IP_BLOCK_2' => $ip_array [1],'IP_BLOCK_3' => $ip_array [2],'IP_BLOCK_4' => $ip_array [3]);
          //array_push($ip_arrary,$details);


        }

        $columns = array_column($device_arrary, 'IP_BLOCK_4');
        array_multisort($columns, SORT_ASC, $device_arrary);

        foreach ( $device_arrary as $var ) {
          if($var['IP'] != "") {
            echo '<tr>';
            echo '<td>',$var['IP'],'</td>';
            echo '<td>',$var['MAC Address'],'</td>';
            echo '<td>',str_replace("(Unknown)","",$var['Vendor']),'</td>';
            echo '</tr>';
          }
        }
      ?>   
  </tbody>
</table>
