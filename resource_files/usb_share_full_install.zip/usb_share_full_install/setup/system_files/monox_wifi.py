#!/usr/bin/python3

import os
import subprocess
import time
import socket
import sys
import re

with open('/etc/wpa_supplicant/wpa_supplicant.conf','r') as f:
    in_file = f.read()
    f.close()

ssid = re.search(re.compile('ssid=\"(.*?)\"'), in_file).group(1)
psk = re.search(re.compile('psk=\"(.*?)\"'), in_file).group(1)
print(ssid, psk, flush=True) 

with open('/home/pi/USB_Share/upload/WIFI.txt','w') as f:
    f.writelines(['WIFI account:'+ssid+',\n', 'WIFI password:'+psk+',\n', 'Setting:1,\n\n', 'WIFI account:'+ssid+',\n', 'WIFI password:'+psk+',\n', 'Setting:0,\n'])
    f.close()

