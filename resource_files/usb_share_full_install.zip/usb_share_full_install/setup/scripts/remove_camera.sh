rm -rf /etc/init.d/rpi_camera_stream_init.py

apt-get remove -y python-picamera python3-picamera
apt-get clean
apt-get autopurge -y

update-rc.d rpi_camera_stream_init.py remove
