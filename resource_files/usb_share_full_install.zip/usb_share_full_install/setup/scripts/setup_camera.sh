apt-get update -y
apt-get upgrade -y
apt-get install -y libjpeg8 gcc g++ python-picamera python3-picamera
apt-get clean
apt-get autopurge -y

#mkdir /home/pi/USB_Share/Camera
#chown pi /home/pi/USB_Share/Camera
#chgrp pi /home/pi/USB_Share/Camera

#cd /home/pi/USB_Share/Camera
#wget http://www.create-more.com/usb_share/rpi_camera_stream.py

#chmod +x /home/pi/USB_Share/Camera/rpi_camera_stream.py

#cd /etc/systemd/system
#wget http://www.create-more.com/usb_share/usb_camera_stream.service

#sudo systemctl daemon-reload
#sudo systemctl enable usb_camera_stream.service
#sudo systemctl start usb_camera_stream.service

#cd /etc/init.d
#wget wget http://www.create-more.com/usb_share/rpi_camera_stream_init.py
#chmod +x /etc/init.d/rpi_camera_stream_init.py

#update-rc.d rpi_camera_stream_init.py defaults
#sudo reboot
